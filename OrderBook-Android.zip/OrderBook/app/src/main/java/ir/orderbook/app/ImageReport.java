package ir.orderbook.app;

import android.content.Context;
import android.graphics.*;
import android.text.*;
import java.io.*;
import java.util.*;

/** 480 logical pixels wide, 20px text, rendered at 2x for sharp PNGs. */
public final class ImageReport {
    private static final int WIDTH=480, HEIGHT=1100, PAD=24;
    private final List<File> files=new ArrayList<>();
    private final Context context; private final Store.Company company;
    private Bitmap bitmap;private Canvas canvas;private float y;
    private final String batch=UUID.randomUUID().toString().substring(0,8);
    private ImageReport(Context context,Store.Company company){this.context=context;this.company=company;}
    public static List<File> create(Context ctx,Store.Company company,List<Store.Order> orders)throws IOException{
        ImageReport r=new ImageReport(ctx,company);
        try { r.start();String date="";int index=0;
            for(Store.Order o:orders){if(!date.equals(o.created)){date=o.created;r.line("تاریخ ثبت سفارش: "+date,true);}
                r.line((++index)+". "+o.name,true);
                r.line("قیمت خرید: "+Values.money(o.buy)+" تومان",false);
                r.line("قیمت مصرف: "+Values.money(o.retail)+" تومان",false);
                r.line("اختلاف نسبت به خرید: "+Values.percent(o.buy,o.retail),false);
                r.line("تسویه: "+Values.money(o.days)+" روز  |  تعداد: "+Values.money(o.cartons)+" کارتن",false);
                r.line("تاریخ تحویل: "+o.delivery,false);
                if(!o.note.isEmpty())r.line("توضیحات: "+o.note,false);
                r.y+=16;
            }r.finish();return r.files;
        }finally{if(r.bitmap!=null&&!r.bitmap.isRecycled())r.bitmap.recycle();}
    }
    private StaticLayout layout(String text,boolean bold){TextPaint p=new TextPaint(Paint.ANTI_ALIAS_FLAG);p.setTextSize(20);p.setColor(Color.rgb(25,49,47));p.setTypeface(bold?Typeface.create("sans",Typeface.BOLD):Typeface.create("sans",Typeface.NORMAL));return StaticLayout.Builder.obtain(text,0,text.length(),p,WIDTH-PAD*2).setAlignment(Layout.Alignment.ALIGN_NORMAL).setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL).setLineSpacing(5,1).setIncludePad(true).build();}
    private void start(){bitmap=Bitmap.createBitmap(WIDTH*2,HEIGHT*2,Bitmap.Config.ARGB_8888);canvas=new Canvas(bitmap);canvas.scale(2,2);canvas.drawColor(Color.WHITE);y=24;draw(layout("سفارش‌یار | "+company.name,true));draw(layout("ویزیتور: "+company.visitor+"\nتلفن: "+company.phone,false));draw(layout("صفحهٔ "+(files.size()+1)+" • مبالغ به تومان",false));y+=14;}
    private void draw(StaticLayout l){canvas.save();canvas.translate(PAD,y);l.draw(canvas);canvas.restore();y+=l.getHeight()+6;}
    private void line(String text,boolean bold)throws IOException{
        StaticLayout l=layout(text,bold);
        for(int i=0;i<l.getLineCount();i++){
            int top=l.getLineTop(i),bottom=l.getLineBottom(i),h=bottom-top;
            if(y+h>HEIGHT-30){finish();start();}
            canvas.save();canvas.clipRect(PAD,y,WIDTH-PAD,y+h);
            canvas.translate(PAD,y-top);l.draw(canvas);canvas.restore();y+=h;
        }
        y+=6;
    }
    private void finish()throws IOException{File f=new File(context.getCacheDir(),"orders-"+batch+"-"+(files.size()+1)+".png");try(OutputStream out=new FileOutputStream(f)){if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,out))throw new IOException("PNG failed");}finally{bitmap.recycle();}files.add(f);}
}
