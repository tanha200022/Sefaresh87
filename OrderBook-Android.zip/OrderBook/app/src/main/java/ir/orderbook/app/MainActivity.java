package ir.orderbook.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.sqlite.SQLiteConstraintException;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.math.BigInteger;
import java.util.*;

public class MainActivity extends Activity {
    private final int green=Color.rgb(8,127,112), ink=Color.rgb(25,49,47);
    private Store db; private LinearLayout root, list; private Spinner companiesSpinner, datesSpinner;
    private List<Store.Company> companies=new ArrayList<>();
    private List<Store.Order> visible=new ArrayList<>();
    private long selected=-1; private String dateFilter="همهٔ تاریخ‌ها", pendingFile;
    private boolean loading;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); db=new Store(this);
        if(state!=null){selected=state.getLong("company",-1);dateFilter=state.getString("filter","همهٔ تاریخ‌ها");pendingFile=state.getString("pending");}
        else selected=getPreferences(0).getLong("company",-1);
        root=column();root.setPadding(dp(16),dp(12),dp(16),dp(16));root.setBackgroundColor(Color.rgb(243,247,246));
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(dp(16),insets.getSystemWindowInsetTop()+dp(12),dp(16),insets.getSystemWindowInsetBottom()+dp(12));return insets;});
        setContentView(root);root.requestApplyInsets();
        TextView title=text("سفارش‌یار",true);root.addView(title);root.addView(text("دفتر سفارش شرکت‌ها",false));
        root.addView(text("انتخاب شرکت",true));
        companiesSpinner=new Spinner(this);root.addView(companiesSpinner);
        Button addCompany=button("＋ افزودن شرکت");root.addView(addCompany);addCompany.setOnClickListener(v->companyDialog());
        datesSpinner=new Spinner(this);root.addView(datesSpinner);
        LinearLayout actions=new LinearLayout(this);actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button add=button("افزودن کالا"), export=button("خروجی عکس");
        actions.addView(add,new LinearLayout.LayoutParams(0,-2,1));actions.addView(export,new LinearLayout.LayoutParams(0,-2,1));root.addView(actions);
        add.setOnClickListener(v->{if(company()==null)toast("ابتدا یک شرکت اضافه کنید");else orderDialog(null);});
        export.setOnClickListener(v->export());
        ScrollView scroll=new ScrollView(this);list=column();scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        companiesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(!loading&&pos<companies.size()){long next=companies.get(pos).id;if(next!=selected)dateFilter="همهٔ تاریخ‌ها";selected=next;getPreferences(0).edit().putLong("company",selected).apply();refreshDates();}}
        });
        datesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> p){}
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(!loading){dateFilter=p.getItemAtPosition(pos).toString();render();}}
        });refreshCompanies();
    }
    @Override public void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putLong("company",selected);b.putString("filter",dateFilter);b.putString("pending",pendingFile);}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);return l;}
    private TextView text(String s,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(20);t.setTextColor(ink);t.setPadding(dp(4),dp(6),dp(4),dp(6));t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(20);b.setAllCaps(false);b.setTextColor(green);b.setMinHeight(dp(52));return b;}
    private <T> ArrayAdapter<T> adapter(List<T> items){return new ArrayAdapter<T>(this,android.R.layout.simple_spinner_item,items){
        @Override public View getView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getView(p,v,g);style(t);return t;}
        @Override public View getDropDownView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getDropDownView(p,v,g);style(t);return t;}
        void style(TextView t){t.setTextSize(20);t.setPadding(dp(12),dp(12),dp(12),dp(12));t.setTextColor(ink);t.setSingleLine(false);t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);}
    };}
    private Store.Company company(){for(Store.Company c:companies)if(c.id==selected)return c;return null;}
    private void refreshCompanies(){loading=true;companies=db.companies();companiesSpinner.setAdapter(adapter(companies));int pos=0;for(int i=0;i<companies.size();i++)if(companies.get(i).id==selected)pos=i;
        selected=companies.isEmpty()?-1:companies.get(pos).id;companiesSpinner.setSelection(pos);loading=false;refreshDates();}
    private void refreshDates(){List<String> ds=new ArrayList<>();ds.add("همهٔ تاریخ‌ها");for(Store.Order o:db.orders(selected))if(!ds.contains(o.created))ds.add(o.created);
        int pos=ds.indexOf(dateFilter);if(pos<0){pos=0;dateFilter=ds.get(0);}loading=true;datesSpinner.setAdapter(adapter(ds));datesSpinner.setSelection(pos);loading=false;render();}
    private void render(){list.removeAllViews();visible.clear();Store.Company c=company();if(c==null){list.addView(text("به سفارش‌یار خوش آمدید\nبرای شروع، شرکت و مشخصات ویزیتور را اضافه کنید.",false));return;}
        TextView companyTitle=text(c.name+"\nویزیتور: "+c.visitor+"\nتلفن: "+c.phone,true);list.addView(companyTitle);companyTitle.setOnClickListener(v->{dateFilter="همهٔ تاریخ‌ها";refreshDates();});
        for(Store.Order o:db.orders(selected))if(dateFilter.equals("همهٔ تاریخ‌ها")||dateFilter.equals(o.created))visible.add(o);
        BigInteger total=BigInteger.ZERO;for(Store.Order o:visible)total=total.add(BigInteger.valueOf(o.cartons));
        list.addView(text(visible.size()+" قلم سفارش  •  "+total+" کارتن",false));
        if(visible.isEmpty())list.addView(text("هنوز سفارشی ثبت نشده است.\nبا «افزودن کالا» شروع کنید.",false));
        String last="";for(Store.Order o:visible){if(!last.equals(o.created)){last=o.created;list.addView(text("تاریخ ثبت سفارش: "+last,true));}
            LinearLayout card=column();card.setPadding(dp(12),dp(8),dp(12),dp(12));GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(18));bg.setStroke(dp(1),Color.rgb(219,231,228));card.setBackground(bg);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));list.addView(card,lp);
            card.addView(text(o.name,true));card.addView(text("خرید: "+Values.money(o.buy)+" تومان\nمصرف: "+Values.money(o.retail)+" تومان\nاختلاف نسبت به خرید: "+Values.percent(o.buy,o.retail)+"\nتسویه: "+Values.money(o.days)+" روز\nتعداد: "+Values.money(o.cartons)+" کارتن\nتحویل: "+o.delivery,false));
            if(!o.note.isEmpty())card.addView(text("توضیحات: "+o.note,false));
            LinearLayout bar=new LinearLayout(this);Button edit=button("ویرایش"),del=button("حذف");bar.addView(edit,new LinearLayout.LayoutParams(0,-2,1));bar.addView(del,new LinearLayout.LayoutParams(0,-2,1));card.addView(bar);
            edit.setOnClickListener(v->orderDialog(o));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف کالا").setMessage("«"+o.name+"» حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف",(d,w)->{db.delete(o.id);refreshDates();}).show());
        }
    }
    private EditText field(LinearLayout form,String label,String value,int type,int max){form.addView(text(label,false));EditText e=new EditText(this);e.setTextSize(20);e.setInputType(type);e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});e.setText(value);form.addView(e);return e;}
    private void grouping(EditText e){e.addTextChangedListener(new TextWatcher(){boolean busy;public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){}public void afterTextChanged(Editable t){if(busy)return;String raw=Values.ascii(t.toString()).replace(",", "").replace("٬", "");if(raw.isEmpty()||!raw.matches("[0-9]+"))return;try{String fmt=Values.money(Long.parseLong(raw));if(!fmt.equals(t.toString())){int old=e.getSelectionStart(),digits=0;for(int i=0;i<Math.min(old,t.length());i++)if(Character.isDigit(t.charAt(i)))digits++;busy=true;e.setText(fmt);int p=0,n=0;while(p<fmt.length()&&n<digits){if(Character.isDigit(fmt.charAt(p)))n++;p++;}e.setSelection(p);busy=false;}}catch(NumberFormatException ignored){busy=false;}}});}
    private AlertDialog dialog(String title,LinearLayout form){ScrollView sc=new ScrollView(this);form.setPadding(dp(18),dp(8),dp(18),dp(16));sc.addView(form);AlertDialog d=new AlertDialog.Builder(this).setTitle(title).setView(sc).setNegativeButton("انصراف",null).setPositiveButton("ثبت",null).create();d.show();d.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);d.getButton(-1).setTextSize(20);d.getButton(-2).setTextSize(20);return d;}
    private String required(EditText e,String message){String s=e.getText().toString().trim();if(s.isEmpty()){e.setError(message);e.requestFocus();throw new IllegalArgumentException(message);}return s;}
    private void companyDialog(){LinearLayout f=column();EditText name=field(f,"نام شرکت","",1,100),visitor=field(f,"نام ویزیتور","",1,100),phone=field(f,"تلفن ویزیتور","",3,20);AlertDialog d=dialog("افزودن شرکت",f);d.getButton(-1).setOnClickListener(v->{try{String n=required(name,"نام شرکت را وارد کنید"),vis=required(visitor,"نام ویزیتور را وارد کنید"),p=Values.ascii(required(phone,"تلفن را وارد کنید")).replace(" ","").replace("-","");if(!p.matches("\\+?[0-9]{7,15}")){phone.setError("شماره معتبر وارد کنید");return;}selected=db.addCompany(n,vis,p);dateFilter="همهٔ تاریخ‌ها";d.dismiss();refreshCompanies();}catch(SQLiteConstraintException e){name.setError("این شرکت قبلاً ثبت شده است");}catch(IllegalArgumentException e){toast(e.getMessage());}});}
    private void orderDialog(Store.Order old){final long companyId=selected;LinearLayout f=column();
        EditText name=field(f,"نام کالا",old==null?"":old.name,1,100);
        EditText buy=field(f,"قیمت خرید (تومان)",old==null?"":Values.money(old.buy),2,18),retail=field(f,"قیمت مصرف (تومان)",old==null?"":Values.money(old.retail),2,18);grouping(buy);grouping(retail);
        TextView percent=text("اختلاف نسبت به خرید: —",true);f.addView(percent);f.addView(text("(مصرف − خرید) ÷ خرید × ۱۰۰",false));
        TextWatcher update=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){}public void afterTextChanged(Editable e){try{percent.setText("اختلاف نسبت به خرید: "+Values.percent(Values.number(buy.getText().toString(),1,999999999999L),Values.number(retail.getText().toString(),0,999999999999L)));}catch(IllegalArgumentException x){percent.setText("اختلاف نسبت به خرید: —");}}};buy.addTextChangedListener(update);retail.addTextChangedListener(update);update.afterTextChanged(buy.getText());
        EditText days=field(f,"مدت تسویه (روز)",old==null?"":Values.money(old.days),2,8),cartons=field(f,"تعداد سفارش (کارتن کامل)",old==null?"":Values.money(old.cartons),2,10);grouping(days);grouping(cartons);
        EditText delivery=field(f,"تاریخ تحویل شمسی — سال/ماه/روز",old==null?Values.today():old.delivery,InputType.TYPE_CLASS_DATETIME|InputType.TYPE_DATETIME_VARIATION_DATE,10);delivery.setTextDirection(View.TEXT_DIRECTION_LTR);
        EditText note=field(f,"توضیحات (اختیاری)",old==null?"":old.note,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE,500);note.setMinLines(3);
        AlertDialog d=dialog(old==null?"افزودن کالا":"ویرایش کالا",f);d.getButton(-1).setOnClickListener(v->{try{Store.Order o=new Store.Order();o.company=companyId;o.id=old==null?0:old.id;o.created=old==null?Values.today():old.created;o.name=required(name,"نام کالا را وارد کنید");o.buy=readNumber(buy,1,999999999999L);o.retail=readNumber(retail,0,999999999999L);o.days=readNumber(days,0,36500);o.cartons=readNumber(cartons,1,1000000);try{o.delivery=Values.date(delivery.getText().toString());}catch(IllegalArgumentException x){delivery.setError(x.getMessage());delivery.requestFocus();throw x;}o.note=note.getText().toString().trim();db.save(o);dateFilter="همهٔ تاریخ‌ها";d.dismiss();refreshDates();}catch(IllegalArgumentException x){toast(x.getMessage());}});
    }
    private long readNumber(EditText e,long min,long max){try{return Values.number(e.getText().toString(),min,max);}catch(IllegalArgumentException x){e.setError(x.getMessage());e.requestFocus();throw x;}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void export(){if(visible.isEmpty()){toast("سفارشی برای خروجی وجود ندارد");return;}Store.Company c=company();List<Store.Order> snapshot=new ArrayList<>(visible);toast("در حال آماده‌سازی تصاویر…");new Thread(()->{try{List<File> files=ImageReport.create(this,c,snapshot);runOnUiThread(()->{if(isFinishing()||isDestroyed())return;String[] names=new String[files.size()];for(int i=0;i<names.length;i++)names[i]="ذخیرهٔ تصویر "+(i+1)+" از "+names.length;new AlertDialog.Builder(this).setTitle("خروجی خوانا • فونت ۲۰").setItems(names,(dialog,which)->saveImage(files.get(which))).setNegativeButton("بستن",null).show();});}catch(Exception|OutOfMemoryError e){runOnUiThread(()->toast("ساخت تصویر ممکن نشد؛ یک تاریخ را انتخاب کنید و دوباره تلاش کنید."));}}).start();}
    private void saveImage(File file){pendingFile=file.getAbsolutePath();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/png");i.putExtra(Intent.EXTRA_TITLE,file.getName());try{startActivityForResult(i,10);}catch(ActivityNotFoundException e){toast("برنامهٔ مدیریت فایل در دسترس نیست");}}
    @Override public void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=10||result!=RESULT_OK||data==null||data.getData()==null||pendingFile==null)return;String path=pendingFile;pendingFile=null;android.net.Uri uri=data.getData();new Thread(()->{try(InputStream in=new FileInputStream(path);OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);runOnUiThread(()->toast("تصویر ذخیره شد"));}catch(IOException e){runOnUiThread(()->toast("ذخیره تصویر انجام نشد؛ دوباره تلاش کنید"));}}).start();}
    @Override public void onDestroy(){db.close();super.onDestroy();}
}
